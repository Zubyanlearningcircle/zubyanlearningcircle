# Zubyan Learning Circle

An educational website built with HTML, CSS and JavaScript.

## Features
- Responsive homepage
- AMU & JMI entrance section
- Arabic language learning
- School resources
- Easy deployment on GitHub Pages

## Run locally
Open `index.html` in a browser.

## Deploy
Upload to GitHub and enable GitHub Pages from **Settings → Pages**.
